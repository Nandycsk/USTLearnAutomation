package TestData;

import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.WebDriver;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;

public class Exceldata {
    XSSFWorkbook wb;

    public  Exceldata(WebDriver driver) throws IOException {

    File src= new File("./TestData/Data.xlsx");
    FileInputStream Fis= new FileInputStream(src);
        wb= new XSSFWorkbook(Fis);

       }

    public String getStringData(int Sheetindex, int row, int column) {

        return wb.getSheetAt(Sheetindex).getRow(row).getCell(column).getStringCellValue();
    }

    public String getStringData(String Sheetname, int row, int column) {

        return wb.getSheet(Sheetname).getRow(row).getCell(column).getStringCellValue();
    }

    public double getNumericData(String Sheetname, int row, int column) {

        return wb.getSheet(Sheetname).getRow(row).getCell(column).getNumericCellValue();
    }
    }