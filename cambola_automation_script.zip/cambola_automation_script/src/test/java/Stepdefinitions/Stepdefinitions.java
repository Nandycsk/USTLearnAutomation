package Stepdefinitions;

import PageObjects.CustomerRegisterandLoginPage;
import PageObjects.E2ECustomerWorkflowCambolaTN;
import PageObjects.SellerRegisterandLoginPage;
import TestData.Exceldata;
import Utilities.Base;
import io.cucumber.java.*;
import io.cucumber.java.Scenario;
import io.cucumber.java.en.*;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.io.IOException;

public class Stepdefinitions extends Base {

    CustomerRegisterandLoginPage customer;
    SellerRegisterandLoginPage seller;
    E2ECustomerWorkflowCambolaTN custE2E= new E2ECustomerWorkflowCambolaTN(driver);
    private static Logger log = LogManager.getLogger(Stepdefinitions.class.getName());

    @After
    public void tearDown(Scenario scenario) throws IOException {
        if (scenario.isFailed()) {
            getScreenshotpath(scenario.getName());
            driver.close();
            log.debug("Test Failed");

        }
    }

    @Given("User is on Cambola login page")
    public void user_is_on_Cambola_login_page() throws Exception {
    invokeDriver();
    driver.get(url);
    log.debug("User is on login page");
    }

    @When("User clicks on Register as Customer button and enters the valid informations & Submit")
    public void User_clicks_on_Register_as_Customer_button_and_enters_the_valid_informations() throws InterruptedException {
        customer = new CustomerRegisterandLoginPage(driver);
        customer.signup(username, email, password, cnfpassword);
        log.debug("Clicks on Register as Customer button and enters the valid informations");
    }

    @Then("User should be redirected to the login page")
    public void user_should_be_redirected_to_the_login_page() {
        driver.getTitle();
        log.debug("User should be redirected to the login page");
    }


    @Then("User enters valid credentials and clicks on login button")
    public void user_enters_valid_credentials_and_clicks_on_login_button() {
        try {
            customer.signin(username, password);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        log.debug("User enters valid credentials and clicks on login button");
    }

    @Then("User should be logged in Successfully")
    public void user_should_be_logged_in_Successfully() {
        driver.getTitle();
        log.debug("User should be logged in Successfully");
    }

    @Then("User logs out of the application")
    public void user_logs_out_of_the_application() {
    //driver.quit();
        log.debug("User logs out of the application");
    }


    @Given("Seller is on Cambola login page")
    public void seller_is_on_Cambola_login_page() throws IOException {
        invokeDriver();
        driver.get(url);
        log.debug("User is on login page");
    }

    @When("Seller clicks on Register as Seller button and enters the valid informations & Submit")
    public void seller_clicks_on_Register_as_Seller_button_and_enters_the_valid_informations_Submit() throws InterruptedException {
    seller= new SellerRegisterandLoginPage(driver);
    seller.signup(sellerusername, selleremail, sellerpassword, sellercnfpassword);
    log.debug("Seller clicks on Register as Seller button and enters the valid informations & Submit");
    }

    @Then("Seller should be redirected to the login page")
    public void seller_should_be_redirected_to_the_login_page() {
        driver.getTitle();
        log.debug("Seller should be redirected to the login page");
    }

    @Then("Seller enters valid credentials and clicks on login button")
    public void seller_enters_valid_credentials_and_clicks_on_login_button() {
        try {
            seller.signin(sellerusername, sellerpassword);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        log.debug("Seller enters valid credentials and clicks on login button");
    }

    @Then("Seller should be logged in Successfully")
    public void seller_should_be_logged_in_Successfully() {
        driver.getTitle();
        log.debug("Seller should be logged in Successfully");
    }

    @Then("Seller logs out of the application")
    public void seller_logs_out_of_the_application() {
    //driver.quit();
        log.debug("Seller logs out of the application");
    }

    //E2E Customer Workflow

    @Given("Registered Customer is on the login page")
    public void registered_Customer_is_on_the_login_page() throws IOException {
        invokeDriver();
        driver.get(url);
        log.debug("Registered Customer is on login page");
    }

    @Then("Customer enters valid credentials and clicks on login button")
    public void customer_enters_valid_credentials_and_clicks_on_login_button() {
        try {
            custE2E.login(username, password);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        log.debug("Customer enters valid credentials and clicks on login button");
    }

    @Then("Customer should be logged in Successfully")
    public void customer_should_be_logged_in_Successfully() {
        driver.getTitle();
        log.debug("Customer should be redirected to the login page");
    }

    @Then("Customer selects the {string} seller in the Home page")
    public void customer_selects_the_seller_in_the_Home_page(String string) {
        try {
            custE2E.selectSeller();
            driver.getTitle();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        log.debug("Customer selects the Cambola TN seller in the Home page");
    }

    @Then("Customer selects {string} in Categories of {string} seller")
    public void customer_selects_in_Categories_of_seller() {
        driver.getTitle();
        log.debug("Customer selects Beauty & Hygiene in Categories of Cambola TN seller");
    }

    @Then("Customer selects the {string}, \"Quantity and clicks Add")
    public void customer_selects_the_Quantity_and_clicks_Add() {
        custE2E.selectProduct();
        driver.getTitle();
        log.debug("customer_selects_the_Quantity_and_clicks_Add");
    }

    @Then("Customer proceeds with Billing & Shipping details")
    public void customer_proceeds_with_Billing_Shipping_details() throws IOException {

        Exceldata excel= new Exceldata(driver);
        String firstname= excel.getStringData("Sheet1", 2, 1);
        String lastname= excel.getStringData("Sheet1", 3, 1);
        String streetaddress= excel.getStringData("Sheet1", 4, 1);
        String city= excel.getStringData("Sheet1", 5, 1);
        String searchlocation= excel.getStringData("Sheet1", 6, 1);
        custE2E.billingandShipping();
    }


    @Then("selects the Payment options and place the order")
    public void selects_the_Payment_options_and_place_the_order() {

    }

    @Then("Receive the order confirmation details")
    public void receive_the_order_confirmation_details() {

    }


}
