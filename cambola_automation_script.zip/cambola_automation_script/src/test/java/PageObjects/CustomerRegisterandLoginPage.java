package PageObjects;

import Utilities.Base;
import com.paulhammant.ngwebdriver.NgWebDriver;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class CustomerRegisterandLoginPage extends Base {

WebDriver driver;
NgWebDriver ngdriver;

    @FindBy(linkText="Register As Customer") public WebElement customerRegistration;

    @FindBy(name="user_login") public WebElement userName;

    @FindBy(name="user_email") public WebElement emailID;

    @FindBy(name="user_pass") public WebElement passwordSignup;

    @FindBy(name="confirm_pass") public WebElement confirmPassword;

    @FindBy(xpath="//input[@value='Submit']") public WebElement btnSubmit;

    @FindBy(id="username") WebElement getUserName;

    @FindBy(id="password") WebElement getPassword;

    @FindBy(id="submits") WebElement getBtnLogin;

    @FindBy(xpath ="//a[@href='https://qa.cambola-dev.com/my-account/']") public  WebElement getMyAccount;

    @FindBy(xpath = "//span[contains(text(), 'Logout')]") public  WebElement getLogout;

    public CustomerRegisterandLoginPage(WebDriver driver) {
        this.driver=driver;
        PageFactory.initElements(driver, this);
    }

    public  void signup(String username, String email, String password, String cnfpassword) throws InterruptedException {
        click(customerRegistration);
        userName.sendKeys(username);
        emailID.sendKeys(email);
        passwordSignup.sendKeys(password);
        confirmPassword.sendKeys(cnfpassword);
        getFullscreenScreenshot(driver);
        btnSubmit.click();
    }

    public  void signin(String username, String password) throws InterruptedException {
        Thread.sleep(2000);
        getUserName.sendKeys(username);
        getPassword.sendKeys(password);
        getFullscreenScreenshot(driver);
        click(getBtnLogin);
        System.out.println(getMyAccount.getText());
        jsclick(getMyAccount);
        getFullscreenScreenshot(driver);
        getLogout.click();
    }
}
