package PageObjects;

import Utilities.Base;
import com.paulhammant.ngwebdriver.NgWebDriver;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class SellerRegisterandLoginPage extends Base {

    WebDriver driver;
    NgWebDriver ngdriver;
    @FindBy(linkText="Register As Seller") public WebElement sellerRegistration;

    @FindBy(name="user_login") public WebElement userName;

    @FindBy(name="user_email") public WebElement emailID;

    @FindBy(name="user_pass") public WebElement passwordSignup;

    @FindBy(name="confirm_pass") public WebElement confirmPassword;

    @FindBy(xpath="//input[@value='Submit']") public WebElement btnSubmit;

    @FindBy(id="username") public WebElement getUserName;

    @FindBy(id="password") public WebElement getPassword;

    @FindBy(id="submits") public WebElement getBtnLogin;

    @FindBy(xpath = "//span[contains(text(), 'Logout')]") public  WebElement getLogout;

    public SellerRegisterandLoginPage(WebDriver driver){
        this.driver= driver;
        PageFactory.initElements(driver, this);
    }

    public  void signup(String sellerusername, String selleremail, String sellerpassword, String sellercnfpassword) throws InterruptedException {
        click(sellerRegistration);
        userName.sendKeys(sellerusername);
        emailID.sendKeys(selleremail);
        passwordSignup.sendKeys(sellerpassword);
        confirmPassword.sendKeys(sellercnfpassword);
        btnSubmit.click();
    }

    public  void signin(String sellerusername, String sellerpassword) throws InterruptedException {
        Thread.sleep(2000);
        getUserName.sendKeys(sellerusername);
        getPassword.sendKeys(sellerpassword);
        click(getBtnLogin);
        getLogout.click();
    }
}
