package PageObjects;

import Utilities.Base;
import com.paulhammant.ngwebdriver.NgWebDriver;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class E2ECustomerWorkflowCambolaTN extends Base {

    WebDriver driver;
    NgWebDriver ngWebDriver;

    @FindBy(id="username") WebElement getUserName;
    @FindBy(id="password") WebElement getPassword;
    @FindBy(id="submits") WebElement getBtnLogin;
    @FindBy(xpath ="//a[@href='https://qa.cambola-dev.com/my-account/']") public  WebElement getMyAccount;
    @FindBy(xpath = "//*[contains(text(),'Cambola TN')]") public WebElement sellerCambolaTN;
    @FindBy(xpath = "(//img[@class='card-img-top'])[1]") public  WebElement categoryBeautyandHygiene;
    @FindBy(xpath = "(//span[@class='increase icon_plus'])[1]") public  WebElement plusTarget;
    @FindBy(xpath = "//button[@value='6376']") public  WebElement btnAdd;
    @FindBy(xpath = "//*[contains(text(),'Proceed')]") public WebElement btnProceed;
    @FindBy(name="billing_first_name") WebElement firstName;
    @FindBy(name="billing_last_name") WebElement lastName;
    @FindBy(id="billing_address_1") WebElement streetAddress1;
    @FindBy(id="billing_city") WebElement custCity;
    @FindBy(id="billing_postcode") WebElement custPostcode;
    @FindBy(id="billing_phone") WebElement custPhoneNo;
    @FindBy(id="MapSearchInput") WebElement searchLocation;
    @FindBy(id="place_order") WebElement placeOrder;

    public E2ECustomerWorkflowCambolaTN(WebDriver driver){
        this.driver= driver;
        PageFactory.initElements(driver, this);
    }

    public  void login(String username, String password) throws InterruptedException {
        Thread.sleep(2000);
        getUserName.sendKeys(username);
        getPassword.sendKeys(password);
        click(getBtnLogin);
    }

    public void selectSeller() throws InterruptedException {
        exlplicitwait(getMyAccount, 10);
        getFullscreenScreenshot(driver);
        sellerCambolaTN.click();
        categoryBeautyandHygiene.click();

    }
    public void selectProduct(){
        Actions Act= new Actions(driver);
        Act.moveToElement(plusTarget);
        plusTarget.click();
        btnAdd.click();
        btnProceed.click();
}
    public void billingandShipping(String firstname , String lastname, String streetaddress, String city, Integer postcode, Integer phoneno, String searchlocation){
        firstName.sendKeys(firstname);
        lastName.sendKeys(lastname);
        streetAddress1.sendKeys(streetaddress);
        custCity.sendKeys(city);
        custPostcode.sendKeys("685004");
        custPhoneNo.sendKeys("9654876510");
        searchLocation.sendKeys(searchlocation);
        searchLocation.sendKeys(Keys.DOWN);
        placeOrder.click();
    }

    public void billingandShipping() {
    }
}
