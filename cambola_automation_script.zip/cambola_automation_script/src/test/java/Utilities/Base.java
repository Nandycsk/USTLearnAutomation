package Utilities;

import com.paulhammant.ngwebdriver.NgWebDriver;
import org.apache.commons.io.FileUtils;
import org.openqa.selenium.*;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import ru.yandex.qatools.ashot.AShot;
import ru.yandex.qatools.ashot.Screenshot;
import ru.yandex.qatools.ashot.shooting.ShootingStrategies;

import javax.imageio.ImageIO;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Properties;
import java.util.concurrent.TimeUnit;

public class Base {
    public static WebDriver driver;
    public NgWebDriver ngDriver;
    public String url;
    public String username;
    public String email;
    public String browsername;
    public String password;
    public String cnfpassword;
    public String sellerusername;
    public String selleremail;
    public String sellerpassword;
    public String sellercnfpassword;
    WebDriverWait wait;


    public WebDriver invokeDriver() throws IOException {

            String configfilepath = System.getProperty("user.dir") + "\\resources" + "\\config.properties";
            FileInputStream filepath = new FileInputStream(configfilepath);
            Properties page = new Properties();
            page.load(filepath);
            browsername = page.getProperty("browser");
            String chromedriverpath = System.getProperty("user.dir") + "\\Browserdriver" + "\\chromedriver.exe";
            String firefoxdriverpath = System.getProperty("user.dir") + "\\Browserdriver" + "\\geckodriver.exe";
            String internetexplorerpath = System.getProperty("user.dir") + "\\Browserdriver" + "\\msedgedriver.exe";

        if (browsername.equals("chrome")) {

            System.setProperty("webdriver.chrome.driver", chromedriverpath);
            driver = new ChromeDriver();
            ngDriver = new NgWebDriver((JavascriptExecutor) driver);
            ngDriver.waitForAngularRequestsToFinish();
        } else if (browsername.equals("firefox")) {
            System.setProperty("webdriver.gecko.driver", firefoxdriverpath);
            driver = new FirefoxDriver();
        } else {
            System.setProperty("webdriver.ie.drive", internetexplorerpath);
            driver = new EdgeDriver();
        }
        url = page.getProperty("url");
        username = page.getProperty("username");
        email = page.getProperty("email");
        password = page.getProperty("password");
        cnfpassword = page.getProperty("confirmpassword");
        sellerusername = page.getProperty("sellerusername");
        selleremail = page.getProperty("selleremail");
        sellerpassword = page.getProperty("sellerpassword");
        sellercnfpassword = page.getProperty("sellerconfirmpassword");

        driver.manage().window().maximize();
        driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
        return driver;
    }



    public String getScreenshotpath(String methodname) throws IOException {
        TakesScreenshot takesScreenshot = (TakesScreenshot) driver;
        File source = takesScreenshot.getScreenshotAs(OutputType.FILE);
        String destination = System.getProperty("user.dir") + "\\reports\\" + "\\Failedscreenshots\\" + methodname + "_screenshot.png";
        FileUtils.copyFile(source, new File(destination));
        return destination;
    }

    public String getFullscreenScreenshot (WebDriver driver){

        try {
            Screenshot screenshot=new AShot().shootingStrategy(ShootingStrategies.viewportPasting(1000)).takeScreenshot(driver);
            String dest = System.getProperty("user.dir") + "\\screen\\" + "\\Cambolascreenshots\\" + getCurrentDateTime()+"_screenshot.png";
            ImageIO.write(screenshot.getImage(),"PNG",new File(dest));
            return dest;
        } catch (IOException e) {
            e.printStackTrace();
        }
        return null;
    }

    public static String getCurrentDateTime() {
        DateFormat customFormat = new SimpleDateFormat("MM_dd_yyyy_HH_mm_ss");
        Date currendate = new Date();
        return customFormat.format(currendate);
    }
    public void exlplicitwait(WebElement element, long milliseconds) throws InterruptedException {
        Thread.sleep(milliseconds);
        WebDriverWait wait = new WebDriverWait(driver, 20);
        JavascriptExecutor executor = (JavascriptExecutor) driver;
        ExpectedCondition<Boolean> pageLoadCondition =
                driver -> ((JavascriptExecutor) driver).executeScript("return document.readyState").toString().equals("complete");
        wait.until(pageLoadCondition);
        if ((Boolean) executor.executeScript("return window.jQuery != undefined")) {
            while (true) {
                Boolean ajaxIsComplete = (Boolean) ((JavascriptExecutor) driver).executeScript("return jQuery.active == 0");
                if (ajaxIsComplete) {
                    break;
                }
            }
        }
        driver.manage().timeouts().setScriptTimeout(45, TimeUnit.SECONDS);
        ngDriver = new NgWebDriver((JavascriptExecutor) driver);
        ngDriver.waitForAngularRequestsToFinish();
        wait.until(ExpectedConditions.visibilityOf(element));
        wait.until(ExpectedConditions.elementToBeClickable(element));

    }
    public void click(WebElement element) throws InterruptedException {
        JavascriptExecutor executor = (JavascriptExecutor) driver;
        wait = new WebDriverWait(driver, 20);
        try {
            ExpectedCondition<Boolean> pageLoadCondition =
                    driver -> ((JavascriptExecutor) driver).executeScript("return document.readyState").toString().equals("complete");
            wait.until(pageLoadCondition);
            if ((Boolean) executor.executeScript("return window.jQuery != undefined")) {
                while (true) {
                    Boolean ajaxIsComplete = (Boolean) ((JavascriptExecutor) driver).executeScript("return jQuery.active == 0");
                    if (ajaxIsComplete) {
                        break;
                    }
                }
            }
            driver.manage().timeouts().setScriptTimeout(45, TimeUnit.SECONDS);
            ngDriver = new NgWebDriver((JavascriptExecutor) driver);
            ngDriver.withRootSelector("app-root").waitForAngularRequestsToFinish();
            wait.until(ExpectedConditions.visibilityOf(element));
            wait.until(ExpectedConditions.elementToBeClickable(element));
            element.click();

        } catch (ElementClickInterceptedException e) {
            e.printStackTrace();

        } catch (StaleElementReferenceException e) {
            e.printStackTrace();
            ExpectedCondition<Boolean> pageLoadCondition =
                    driver -> ((JavascriptExecutor) driver).executeScript("return document.readyState").toString().equals("complete");
            wait = new WebDriverWait(driver, 20);
            wait.until(pageLoadCondition);
            if ((Boolean) executor.executeScript("return window.jQuery != undefined")) {
                while (true) {
                    Boolean ajaxIsComplete = (Boolean) ((JavascriptExecutor) driver).executeScript("return jQuery.active == 0");
                    if (ajaxIsComplete) {
                        break;
                    }
                }
            }
            driver.manage().timeouts().setScriptTimeout(45, TimeUnit.SECONDS);
            ngDriver = new NgWebDriver((JavascriptExecutor) driver);
            ngDriver.withRootSelector("app-root").waitForAngularRequestsToFinish();
            wait.until(ExpectedConditions.visibilityOf(element));
            wait.until(ExpectedConditions.elementToBeClickable(element));
            element.click();
        }

    }


    public void jsclick(WebElement element) {
        wait = new WebDriverWait(driver, 15);
        try {
            ExpectedCondition<Boolean> pageLoadCondition =
                    driver -> ((JavascriptExecutor) driver).executeScript("return document.readyState").toString().equals("complete");
            wait.until(pageLoadCondition);
            JavascriptExecutor executor = (JavascriptExecutor) driver;
            if ((Boolean) executor.executeScript("return window.jQuery != undefined")) {
                while (true) {
                    Boolean ajaxIsComplete = (Boolean) ((JavascriptExecutor) driver).executeScript("return jQuery.active == 0");
                    if (ajaxIsComplete) {
                        break;
                    }
                }
            }
            driver.manage().timeouts().setScriptTimeout(45, TimeUnit.SECONDS);
            ngDriver = new NgWebDriver((JavascriptExecutor) driver);
            ngDriver.withRootSelector("app-root").waitForAngularRequestsToFinish();
            wait.until(ExpectedConditions.visibilityOf(element));
            wait.until(ExpectedConditions.elementToBeClickable(element));
            executor.executeScript("arguments[0].click();", element);
        } catch (StaleElementReferenceException e) {
            e.printStackTrace();
            ExpectedCondition<Boolean> pageLoadCondition =
                    driver -> ((JavascriptExecutor) driver).executeScript("return document.readyState").toString().equals("complete");
            wait = new WebDriverWait(driver, 20);
            wait.until(pageLoadCondition);
            driver.manage().timeouts().setScriptTimeout(35, TimeUnit.SECONDS);
            ngDriver = new NgWebDriver((JavascriptExecutor) driver);
            ngDriver.withRootSelector("app-root").waitForAngularRequestsToFinish();
            JavascriptExecutor executor = (JavascriptExecutor) driver;
            wait.until(ExpectedConditions.visibilityOf(element));
            wait.until(ExpectedConditions.elementToBeClickable(element));
            executor.executeScript("arguments[0].click();", element);
        } catch (ElementNotInteractableException e) {
            e.printStackTrace();

        }
    }
    public void waitforangularload() {
        driver.manage().timeouts().setScriptTimeout(35, TimeUnit.SECONDS);
        ngDriver = new NgWebDriver((JavascriptExecutor) driver);
        ngDriver.waitForAngularRequestsToFinish();

    }


}


